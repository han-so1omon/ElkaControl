"""
Author: Eric Solomon
Project: Elkaradio Control
Lab: Alfred Gessow Rotorcraft Center
Package: Logging
Module: dataGrapher.py 

Graphs data streams parsed by ElkaControl
"""

class DataPlotter(object):
    def __init__(self):
        pass
