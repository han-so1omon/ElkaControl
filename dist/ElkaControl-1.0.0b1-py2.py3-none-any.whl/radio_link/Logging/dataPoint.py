"""
Author: Eric Solomon
Project: Elkaradio Control
Lab: Alfred Gessow Rotorcraft Center
Package: Logging
Module: dataPoint.py 

Parses inputs, outputs, and acks logs into usable data sets
"""

