"""
Author: Eric Solomon
Project: Crazyradio control of quadrotors
Lab: Alfred Gessow Rotorcraft Center
Package: Commander 

"""
