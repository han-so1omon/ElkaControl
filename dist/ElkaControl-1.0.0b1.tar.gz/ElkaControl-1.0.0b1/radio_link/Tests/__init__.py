'''
Created on Dec 11, 2014

@author: eric
'''

"""
Examples and tests for the edited Crazyflie project.
"""
