from __future__ import division, absolute_import, print_function

import numpydoc.linkcode

# No tests at the moment...
